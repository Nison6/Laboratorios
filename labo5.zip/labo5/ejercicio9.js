function area(){
    var rad = prompt('input', 0);
    var pi = 3.14;
    var area = Math.pow((rad*pi),2);
    console.log("area de circulo: " + area.toFixed(2));
}

area(5);