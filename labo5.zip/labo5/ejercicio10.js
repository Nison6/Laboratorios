function absolute(num){
    if(num>=0){
        console.log(num);
    }else{
        console.log(num*-1);
    }
}

absolute(-2);